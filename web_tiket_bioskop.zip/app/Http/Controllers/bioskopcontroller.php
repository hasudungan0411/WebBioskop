<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class bioskopcontroller extends Controller
{
    public function Bioskop()
    {
        return view('bioskop');
    }
}
