<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class mallbioskopcontroller extends Controller
{
    public function bcs()
    {
        return view('mallbioskop.bcs');
    }
}
