<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use App\Models\Product;
 
class HomeController extends Controller
{
   
 
    public function index()
    {
        // Ambil data film dari database
        $nowPlaying = Product::where('kategori', 'now playing')->get();

        
        // Tampilkan view 'home' dan teruskan data film ke dalam view
        return view('home', compact('nowPlaying'));
    }

   
    
    public function adminHome()
    {
        return view('dashboard');
    }

    public function tiket()
    {
        return view('tiket');
    }
}