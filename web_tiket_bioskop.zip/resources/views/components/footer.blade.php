<footer class=" w-full bg-green-900 text-white text-center py-3 flex-grow">
    © KELOMPOK 2 JAYA JAYA
</footer>