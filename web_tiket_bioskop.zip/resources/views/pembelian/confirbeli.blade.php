@extends('layouts.user')

@section('title', 'Confirmasi Pembelian')

@section('contents')

<div class="min-h-screen">

<h2> Halaman Confirmasi pembelian</h2>

</div>

@endsection
