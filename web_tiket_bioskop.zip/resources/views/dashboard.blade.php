@extends('layouts.app')
 
@section('title', 'Login Admin')
 
@section('contents')
<div>
    <h1 class="font-bold text-2xl ml-3 text-center">Ticket order</h1>
    <hr class="border-t-2 border-black my-4">
    <div class="bg-blue-200 p-60 mt-4 h-full">
        
    </div>
</div>

@endsection