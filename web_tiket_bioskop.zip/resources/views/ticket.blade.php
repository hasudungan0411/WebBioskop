<!DOCTYPE html>
<html>
<head>
    <title>Tiket Elektronik</title>
    <style>
        /* CSS styling untuk tiket */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .ticket-info {
            background-color: #f0f0f0;
            padding: 20px;
            margin-bottom: 20px;
        }
        .ticket-info p {
            margin: 5px 0;
        }
        .ticket-info h2 {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="ticket-info">
            <h2>Film: "{{ $product->judul }}"</h2>
            <p>Lokasi Mall: {{ $movie->mall }}</p>
            <p>Studio: {{ $movie->theater }}</p>
            <p>jadwal Tayang: {{ $movie->date }} - {{ $movie->time }}</p>
            <p>Kursi yang Dipilih:</p>
            <ul>
                @foreach ($transaction->seats as $seat)
                    <li>{{ $seat->seat_number }}</li>
                @endforeach   
            </ul>
            <p>Harga Total: Rp{{ number_format($transaction->total_price, 0, ',', '.') }}</p>
            {{-- <p>Status Pembayaran: {{ ucfirst($transaction->status) }}</p> --}}
        </div>
    </div>
</body>
</html>
