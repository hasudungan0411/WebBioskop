@extends('layouts.user')

@section('title', 'Konfirmasi Pembayaran')

@section('contents')
<div class="container mx-auto py-8">
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-2xl font-semibold mb-4">Konfirmasi Pembayaran untuk {{ $product->judul }}</h1>
        <p>Showtime:{{ $movie->mall }} {{ $movie->date }} - {{ $movie->time }} ({{ $movie->theater }})</p>
        <p>Kursi yang Dipilih:</p>
        <ul>
            @foreach ($seats as $seat)
                <li>{{ $seat->seat_number }}</li>
            @endforeach
        </ul>
        <p>Harga Total: Rp{{ number_format($transaction->total_price, 0, ',', '.') }}</p>

        <!-- Tombol untuk memulai pembayaran dengan Midtrans -->
        <button id="pay-button" onclick="midtrans()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Bayar Sekarang</button>

        
    </div>
</div>
@endsection

@section('scripts')
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ env('MIDTRANS_CLIENT_KEY') }}"></script>
<script type="text/javascript">
    function midtrans (){
        console.log('test');
        snap.pay('{{ $transaction->snap_token }}', {
            onSuccess: function(result){
                alert('Pembayaran Berhasil');
                console.log(result);
                window.location.href = "/payment/success/{{$transaction_id}}" ; // Redirect ke halaman sukses
            },
            onPending: function(result){
                alert('Pembayaran Tertunda');
                console.log(result);
            },
            onError: function(result){
                alert('Pembayaran Gagal');
                console.log(result);
                window.location.href = "/payment/error"; // Redirect ke halaman error
            }
        });
        $(document).ready(function() {
        $('.seat').prop('disabled', true);
    });
    };
</script>
@endsection
