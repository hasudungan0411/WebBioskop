<?php $__env->startSection('title', 'Show Film'); ?>

<?php $__env->startSection('contents'); ?>
<h1 class="font-bold text-2xl ml-3">Detail Film</h1>
<hr />
<div class="border-b border-gray-900/10 pb-12">
    <div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Judul</label>
            <div class="mt-2">
                <?php echo e($product->judul); ?>

            </div>
        </div>

        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Genre</label>
            <div class="mt-2">
                <?php echo e($product->genre); ?>

            </div>
        </div>
        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Harga</label>
            <div class="mt-2">
                <?php echo e($product->harga); ?>

            </div>
        </div>
        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Kategori</label>
            <div class="mt-2">
                <?php echo e($product->kategori); ?>

            </div>
        </div>
        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Trailer</label>
            <div class="mt-2">
                <a href="<?php echo e($product->trailer); ?>" target="_blank">Tonton Trailer</a>
            </div>
        </div>
        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Image</label>
            <div class="mt-2">
                <?php echo e($product->image); ?>

            </div>
        </div>
        <div class="sm:col-span-4">
            <label class="block text-sm font-medium leading-6 text-gray-900">Description</label>
            <div class="mt-2">
                <?php echo e($product->description); ?>

            </div>
        </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\jualtanah\resources\views/products/show.blade.php ENDPATH**/ ?>