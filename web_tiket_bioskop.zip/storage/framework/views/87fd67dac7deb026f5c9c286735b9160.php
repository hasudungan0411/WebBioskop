<!DOCTYPE html>
<html>
<head>
    <title>Tiket Elektronik</title>
    <style>
        /* CSS styling untuk tiket */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .ticket-info {
            background-color: #f0f0f0;
            padding: 20px;
            margin-bottom: 20px;
        }
        .ticket-info p {
            margin: 5px 0;
        }
        .ticket-info h2 {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="ticket-info">
            <h2>Film: "<?php echo e($product->judul); ?>"</h2>
            <p>Lokasi Mall: <?php echo e($movie->mall); ?></p>
            <p>Studio: <?php echo e($movie->theater); ?></p>
            <p>jadwal Tayang: <?php echo e($movie->date); ?> - <?php echo e($movie->time); ?></p>
            <p>Kursi yang Dipilih:</p>
            <ul>
                <?php $__currentLoopData = $transaction->seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($seat->seat_number); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </ul>
            <p>Harga Total: Rp<?php echo e(number_format($transaction->total_price, 0, ',', '.')); ?></p>
            
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/ticket.blade.php ENDPATH**/ ?>