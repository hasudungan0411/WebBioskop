<!-- resources/views/payment/success.blade.php -->



<?php $__env->startSection('title', 'Pembayaran Berhasil'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container mx-auto py-8">
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-2xl font-semibold mb-4 text-center">Pembayaran Berhasil</h1>
        
        <div class="mt-4 text-center">
            <a href="<?php echo e(route('generate.ticket', ['id_transaction' => $id_transaction])); ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                Unduh Tiket</a>
            <a href="<?php echo e(route('home')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Kembali ke Beranda</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/payment/success.blade.php ENDPATH**/ ?>