<?php $__env->startSection('title', 'Pilih Mall'); ?>

<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
<div class="container">
    <h1 class="mb-4">Pilih Mall untuk Film</h1>
    <p>Film ID: <?php echo e($productid); ?></p>

    <?php if($malls->isEmpty()): ?>
        <p>Tidak ada mall yang tersedia.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Mall</th>
                    <th>Lokasi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $malls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($mall->name); ?></td>
                        <td><?php echo e($mall->location); ?></td>
                        <td>
                            <a href="<?php echo e(route('studios.index', ['mall_id' => $mall->id, 'product_id' => $productid])); ?>" class="btn btn-primary">Pilih</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/malls/index.blade.php ENDPATH**/ ?>