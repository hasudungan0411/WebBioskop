<?php $__env->startSection('title', 'Konfirmasi Pembayaran'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container mx-auto py-8">
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-2xl font-semibold mb-4">Konfirmasi Pembayaran untuk <?php echo e($product->judul); ?></h1>
        <p>Showtime:<?php echo e($movie->mall); ?> <?php echo e($movie->date); ?> - <?php echo e($movie->time); ?> (<?php echo e($movie->theater); ?>)</p>
        <p>Kursi yang Dipilih:</p>
        <ul>
            <?php $__currentLoopData = $seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($seat->seat_number); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <p>Harga Total: Rp<?php echo e(number_format($transaction->total_price, 0, ',', '.')); ?></p>

        <!-- Tombol untuk memulai pembayaran dengan Midtrans -->
        <button id="pay-button" onclick="midtrans()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Bayar Sekarang</button>

        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(env('MIDTRANS_CLIENT_KEY')); ?>"></script>
<script type="text/javascript">
    function midtrans (){
        console.log('test');
        snap.pay('<?php echo e($transaction->snap_token); ?>', {
            onSuccess: function(result){
                alert('Pembayaran Berhasil');
                console.log(result);
                window.location.href = "/payment/success/<?php echo e($transaction_id); ?>" ; // Redirect ke halaman sukses
            },
            onPending: function(result){
                alert('Pembayaran Tertunda');
                console.log(result);
            },
            onError: function(result){
                alert('Pembayaran Gagal');
                console.log(result);
                window.location.href = "/payment/error"; // Redirect ke halaman error
            }
        });
        $(document).ready(function() {
        $('.seat').prop('disabled', true);
    });
    };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/confirmpembayaran.blade.php ENDPATH**/ ?>