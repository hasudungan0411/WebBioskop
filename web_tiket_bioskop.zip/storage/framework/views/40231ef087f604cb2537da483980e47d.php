 
<?php $__env->startSection('title', 'Profile Settings User'); ?>
 
<?php $__env->startSection('contents'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<header>
    <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<hr />
<form method="POST" enctype="multipart/form-data" action="<?php echo e(route ('userprofile.update')); ?>">
    <?php echo csrf_field(); ?>
    <div class="w-full bg-gray-300 rounded-lg shadow dark:border md:mt-10 sm:max-w-md xl:p-1 dark:bg-gray-800 dark:border-gray-700 mx-auto" >
    <div class="p-6 space-y-4 md:space-y-5 sm:p-20">
        <div class="flex items-center mb-5 text-5xl font-semibold text-gray-900 dark:text-white">
            <img src="images/logo.png" alt="G2" class="h-20 w-auto" >
            <span class="text-decoration">FilmFlix</span>
        </div>
    <div>
        <label class="label">
            <span class="text-base label-text">Name</span>
        </label>
        <input name="name" type="text" value="<?php echo e(auth()->user()->name); ?>" class="w-full input input-bordered" />
    </div>
    <div>
        <label class="label">
            <span class="text-base label-text">Email</span>
        </label>
        <input name="email" type="text" value="<?php echo e(auth()->user()->email); ?>" class="w-full input input-bordered" />
    </div>
    <div class="mt-6 text-center">
        <button type="submit" class="btn btn-block hover:bg-blue-500">Save Profile</button>
    </div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\jualtanah\resources\views/userprofile.blade.php ENDPATH**/ ?>