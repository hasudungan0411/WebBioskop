<?php $__env->startSection('title', 'Confirmasi Pembelian'); ?>

<?php $__env->startSection('contents'); ?>

<div class="min-h-screen">

<h2> Halaman Confirmasi pembelian</h2>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\jualtanah\resources\views/pembelian/confirbeli.blade.php ENDPATH**/ ?>