<?php $__env->startSection('title', 'Manage movies'); ?>

<?php $__env->startSection('contents'); ?>
<div>
    <h1 class="font-bold text-2xl ml-3">Manage Film</h1>
    <a href="<?php echo e(route('movies.create')); ?>" class="text-white float-right bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Add Showtime Film</a>
    <hr />

    <?php if(session('success')): ?>
    <div class="bg-green-200 text-green-800 py-2 px-4 mb-4 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3">#</th>
                <th scope="col" class="px-6 py-3">Date</th>
                <th scope="col" class="px-6 py-3">Time</th>
                <th scope="col" class="px-6 py-3">Movie Title</th>
                <th scope="col" class="px-6 py-3">Mall</th>
                <th scope="col" class="px-6 py-3">Studio</th>
                <th scope="col" class="px-6 py-3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b bg-white dark:bg-gray-800 dark:border-gray-700">
                <td class="px-6 py-4"><?php echo e($index + 1); ?></td>
                <td class="px-6 py-4"><?php echo e($movie->date); ?></td>
                <td class="px-6 py-4"><?php echo e($movie->time); ?></td>
                <td class="px-6 py-4"><?php echo e($movie->movie_title); ?></td>
                <td class="px-6 py-4"><?php echo e($movie->mall); ?></td>
                <td class="px-6 py-4"><?php echo e($movie->theater); ?></td>
                <td class="px-6 py-4">
                    <a href="<?php echo e(route('movies.edit', $movie->id)); ?>" class="text-blue-600 hover:text-blue-900">Edit</a>
                    <form action="<?php echo e(route('movies.destroy', $movie->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/movies/index.blade.php ENDPATH**/ ?>