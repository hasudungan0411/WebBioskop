<!-- resources/views/pembelian/pilihkursi.blade.php -->



<?php $__env->startSection('title', 'Pilih Kursi'); ?>

<?php $__env->startSection('contents'); ?>
<div class="container mx-auto py-8">
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-3xl font-semibold mb-4">Pilih Kursi</h1>
        <p class="text-gray-600 mb-4">Film: <?php echo e($product->judul); ?></p>
        <p class="text-gray-600 mb-4">Tempat dan jam tayang: <?php echo e($movie->mall); ?> <?php echo e($movie->date); ?> - <?php echo e($movie->time); ?></p>

        <!-- Tabel Kursi -->
        <form id="seatSelectionForm" action="<?php echo e(route('prosespembayaran')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
            <input type="hidden" name="movie_id" value="<?php echo e($movie->id); ?>">
            <input type="hidden" name="selected_seats" id="selectedSeats">

            <div class="grid grid-cols-5 gap-6">
                <?php $__currentLoopData = $seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-2 border rounded <?php echo e($seat->is_reserved ? 'bg-gray-300 cursor-not-allowed' : 'bg-green-200'); ?>">
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" class="seat-checkbox" value="<?php echo e($seat->seat_number); ?>" <?php echo e($seat->is_reserved ? 'disabled' : ''); ?>>
                            <span><?php echo e($seat->seat_number); ?></span>
                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-4">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Proses Pembayaran
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById('seatSelectionForm').addEventListener('submit', function(event) {
        // Kumpulkan kursi yang dipilih
        let selectedSeats = [];
        document.querySelectorAll('.seat-checkbox:checked').forEach(function(checkbox) {
            selectedSeats.push(checkbox.value);
        });
        if (selectedSeats.length === 0) {
            alert('Pilih setidaknya satu kursi');
            event.preventDefault(); 
        }
        // Simpan kursi yang dipilih di input hidden
        document.getElementById('selectedSeats').value = selectedSeats.join(',');

        
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/pilihkursi.blade.php ENDPATH**/ ?>