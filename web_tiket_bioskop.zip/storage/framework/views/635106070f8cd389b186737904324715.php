 
<?php $__env->startSection('title', 'Login Admin'); ?>
 
<?php $__env->startSection('contents'); ?>
<div>
    <h1 class="font-bold text-2xl ml-3 text-center">Ticket order</h1>
    <hr class="border-t-2 border-black my-4">
    <div class="bg-blue-200 p-60 mt-4 h-full">
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/dashboard.blade.php ENDPATH**/ ?>