<header class="bg-white shadow mx-auto md:mt-8">
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold text-gray-900 text-center" >
            Profile
        </h1>
    </div>
</header>
<?php /**PATH C:\Users\lenovo\Documents\jualtanah\resources\views/components/header.blade.php ENDPATH**/ ?>