<?php $__env->startSection('title', 'Pengelolaan Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Pengelolaan Produk</h1>

    <div class="mb-4">
        <h2>Daftar Produk</h2>
        <ul>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($product->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="mb-4">
        <h2>Tambahkan Mall untuk Produk</h2>
        <form action="<?php echo e(route('products.malls.store', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="product_id">Pilih Produk</label>
                <select name="product_id" id="product_id" class="form-control" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="mall_name">Nama Mall</label>
                <input type="text" name="name" id="mall_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="mall_location">Lokasi</label>
                <input type="text" name="location" id="mall_location" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Mall</button>
        </form>
    </div>

    <div class="mb-4">
        <h2>Tambahkan Studio untuk Produk</h2>
        <form action="<?php echo e(route('products.studios.store', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="product_id">Pilih Produk</label>
                <select name="product_id" id="product_id" class="form-control" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="studio_name">Nama Studio</label>
                <input type="text" name="name" id="studio_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="mall_id">Pilih Mall</label>
                <select name="mall_id" id="mall_id" class="form-control" required>
                    <?php $__currentLoopData = $malls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mall->id); ?>"><?php echo e($mall->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Studio</button>
        </form>
    </div>

    <div class="mb-4">
        <h2>Tambahkan Jadwal Penayangan untuk Produk</h2>
        <form action="<?php echo e(route('products.showtimes.store', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="product_id">Pilih Produk</label>
                <select name="product_id" id="product_id" class="form-control" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="jam">Jam</label>
                <input type="time" name="jam" id="jam" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="studio_id">Pilih Studio</label>
                <select name="studio_id" id="studio_id" class="form-control" required>
                    <?php $__currentLoopData = $studios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($studio->id); ?>"><?php echo e($studio->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Jadwal Penayangan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/products/manage.blade.php ENDPATH**/ ?>