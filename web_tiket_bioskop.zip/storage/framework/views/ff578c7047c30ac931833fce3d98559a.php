<footer class=" w-full bg-green-900 text-white text-center py-3 flex-grow">
    © KELOMPOK 2 JAYA JAYA
</footer><?php /**PATH C:\Users\lenovo\Documents\Web-Bioskop\resources\views/components/footer.blade.php ENDPATH**/ ?>