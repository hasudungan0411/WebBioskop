 
 <?php $__env->startSection('title', 'Now Playing'); ?>
  
 <?php $__env->startSection('contents'); ?>
 
 <div class="container">
      <div class="slideshow-container">
        <div class="mySlides fade">
          <img src="images/film8.jpg" style="width:95%">
        </div>

        <div class="mySlides fade">
          <img src="images/film7.jpg" style="width:95%">
        </div>

        <div class="mySlides fade">
          <img src="images/film9.jpg" style="width:95%">
        </div>
      </div>

      <br>
      <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
      </div>

      <script>
        let slideIndex = 0;
        showSlides();

        function showSlides() {
          let i;
          let slides = document.getElementsByClassName("mySlides");
          let dots = document.getElementsByClassName("dot");
          for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
          }
          slideIndex++;
          if (slideIndex > slides.length) {
            slideIndex = 1
          }
          for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
          }
          slides[slideIndex - 1].style.display = "block";
          dots[slideIndex - 1].className += " active";
          setTimeout(showSlides, 1650); // Change image every 2 seconds
        }
      </script>
      <div class='item'>
        <img src="images/film5.jpg" alt="Film 1">
        <h6>Pasar Setan</h6>
      </div>
      <div class='item'>
        <img src="images/film2.jpg" alt="Film 2">
        <h6>Dune: Part Two</h6>
      </div>
      <div class='item'>
        <img src="images/film6.jpg" alt="Film 3">
        <h6>Madame Web</h6>
      </div>
      <div class='item'>
        <img src="images/film4.jpg" alt="Film 4">
        <h6>Perjalanan Pembuktian Cinta</h6>
      </div>
      <div class='item'>
        <img src="images/film1.jpg" alt="Film 5">
        <h6>Kung Fu Panda 4</h6>
      </div>
      <div class='item'>
        <img src="images/film2.jpg" alt="Film 6">
        <h6>Land Of Bad</h6>
      </div>
    </div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\jualtanah\resources\views/nowplaying.blade.php ENDPATH**/ ?>